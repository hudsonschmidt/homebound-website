HOMEBOUND PRESS KIT
https://www.homeboundapp.com/press/


THE SHORT VERSION

Homebound is a free safety app for iPhone and Apple Watch: you set a return
time and pick your safety contacts before you head out. If you're not back by
then, plus your grace period, they get your trip plan and last known location.
Version 1.6, out December 16, adds ski and snowboard tracking, with runs,
vertical, and top speed on your iPhone and Apple Watch.


FACT SHEET

Launch:          Version 1.6, December 16, 2026
Platforms:       iPhone with iOS 26 or later, and Apple Watch with watchOS 26
                 or later
Price:           Free on the App Store, with an optional Homebound+
                 subscription. Homebound+ adds resort trail maps with run and
                 lift names, ski day replays, bigger trip photo albums, more
                 safety contacts per trip, and unlimited trip history. Trips,
                 alerts, SOS, and ski tracking are free.
Availability:    The US, Canada, Australia, and New Zealand
Made in:         Park City, Utah, by Hudson Schmidt
First released:  January 2026
App Store:       https://apps.apple.com/us/app/homebound-check-in/id6754800989
Website:         https://www.homeboundapp.com

Homebound is not an emergency service. It alerts the people you choose.


IN THIS FOLDER

iPhone screenshots/        The 10 App Store screenshots for 1.6 (1284 x 2778)
Apple Watch screenshots/   6 Apple Watch screens (416 x 496)
Logos/                     The app icon, the logo, the logo with the name,
                           and a black and white logo
Photos/
  hudson-schmidt-trail.jpg      Hudson Schmidt on the trail (3000 x 2000).
                                Photo: Chase McClelland
  hudson-schmidt-portrait.jpg   Hudson Schmidt on the salt flats (1600 x 2000).
                                Photo: Chase McClelland
  hudson-schmidt-headshot.jpg   Hudson Schmidt, headshot (874 x 1169).
                                Photo: Joy Conneally
  ski-day.jpg                   A ski day (2400 x 1600).
                                Photo: Hudson Schmidt

Photos and screenshots may be used in coverage of Homebound.


CONTACT

Hudson Schmidt, founder
press@homeboundapp.com
